-- ================================================
-- TRAVEL & TOURISM DATABASE SETUP
-- Run this in phpMyAdmin SQL tab
-- ================================================

CREATE DATABASE IF NOT EXISTS travel_db;
USE travel_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Destinations table
CREATE TABLE IF NOT EXISTS destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image_url VARCHAR(500),
  location VARCHAR(100),
  duration VARCHAR(50),
  rating DECIMAL(3,1) DEFAULT 4.5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  destination_id INT NOT NULL,
  travel_date DATE NOT NULL,
  num_persons INT NOT NULL DEFAULT 1,
  total_price DECIMAL(10,2),
  status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE
);

-- Sample destinations data
INSERT INTO destinations (name, description, price, image_url, location, duration, rating) VALUES
('Goa Beach Paradise', 'Experience the stunning beaches, vibrant nightlife and Portuguese heritage of Goa. Crystal clear waters and golden sands await you.', 8999, 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800', 'Goa, India', '4 Days / 3 Nights', 4.8),
('Shimla Hills Escape', 'Breathtaking Himalayan views, colonial architecture and adventure activities. Perfect mountain retreat away from city life.', 6499, 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800', 'Himachal Pradesh, India', '3 Days / 2 Nights', 4.6),
('Kerala Backwaters', 'Glide through tranquil backwaters on a traditional houseboat, surrounded by lush greenery and coconut palms.', 11999, 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800', 'Kerala, India', '5 Days / 4 Nights', 4.9),
('Rajasthan Royal Tour', 'Explore magnificent forts, palaces and vibrant culture of the royal desert state. A journey through time and grandeur.', 14999, 'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=800', 'Rajasthan, India', '6 Days / 5 Nights', 4.7),
('Manali Adventure', 'Snow-capped mountains, river rafting, and thrilling treks. The ultimate adventure destination in the Indian Himalayas.', 7499, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800', 'Himachal Pradesh, India', '4 Days / 3 Nights', 4.5),
('Andaman Islands', 'Pristine white beaches, clear turquoise water and world-class scuba diving. A true tropical paradise.', 18999, 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=800', 'Andaman & Nicobar, India', '6 Days / 5 Nights', 4.9);

SELECT 'Database setup complete!' as Status;
