# 🌏 WanderLux — How to Run This Project

## What You Need to Install First

1. **Node.js** → https://nodejs.org  (download LTS version)
2. **XAMPP** → https://apachefriends.org  (for MySQL database)
3. **VS Code** → https://code.visualstudio.com
4. **VS Code Extension: Live Server** → Install from VS Code Extensions tab

---

## Step-by-Step Setup

### STEP 1 — Start XAMPP

1. Open XAMPP Control Panel
2. Click **Start** next to **Apache**
3. Click **Start** next to **MySQL**
4. Both should show green "Running"

---

### STEP 2 — Create the Database

1. Open browser → go to **http://localhost/phpmyadmin**
2. Click **"New"** on the left sidebar
3. Type database name: `travel_db` → Click Create
4. Click on `travel_db` in the sidebar
5. Click **"SQL"** tab at the top
6. Open the file `database/setup.sql` from this project
7. Copy all the content → Paste it in the SQL box → Click **Go**
8. You should see ✅ "Database setup complete!"

---

### STEP 3 — Open Project in VS Code

1. Open VS Code
2. File → Open Folder → Select the `travel-tourism` folder
3. Open Terminal in VS Code: **Ctrl + `** (backtick key)

---

### STEP 4 — Install Node.js Packages

In the VS Code terminal, type:

```
npm install
```

Wait for it to finish. You'll see a `node_modules` folder appear.

---

### STEP 5 — Start the Backend Server

In the same terminal, type:

```
node backend/server.js
```

You should see:
```
✅ WanderLux Server running on http://localhost:3000
✅ MySQL Database Connected!
```

**Keep this terminal running!** Don't close it.

---

### STEP 6 — Open the Frontend

1. In VS Code, go to the `frontend` folder
2. Right-click on **`index.html`**
3. Click **"Open with Live Server"**
4. Browser opens at **http://localhost:5500**

---

## Your Project is Now Running! 🎉

| Page | URL |
|------|-----|
| 🏠 Home | http://localhost:5500/frontend/index.html |
| 🔐 Login/Register | http://localhost:5500/frontend/login.html |
| ✈️ Book a Tour | http://localhost:5500/frontend/booking.html |
| 🔧 Admin Panel | http://localhost:5500/frontend/admin.html |

**Admin Login:** username = `admin`, password = `admin123`

---

## Project Structure

```
travel-tourism/
├── frontend/
│   ├── index.html      ← Home page with destinations
│   ├── login.html      ← Login & Register page
│   ├── booking.html    ← Tour booking form
│   └── admin.html      ← Admin dashboard
│
├── backend/
│   ├── server.js       ← Main Express server
│   ├── db.js           ← MySQL database connection
│   └── routes/
│       ├── auth.js         ← Register & Login APIs
│       ├── booking.js      ← Booking API
│       ├── destinations.js ← Destinations API
│       └── admin.js        ← Admin APIs
│
├── database/
│   └── setup.sql       ← Run this in phpMyAdmin
│
├── .env                ← Database & secret settings
└── package.json        ← Node.js dependencies
```

---

## Common Issues & Fixes

| Problem | Fix |
|---------|-----|
| `npm install` fails | Make sure Node.js is installed. Run `node --version` to check. |
| "MySQL Connection Error" | Check XAMPP — MySQL must be running (green) |
| "Cannot GET /" in browser | Make sure you ran `node backend/server.js` |
| Booking not saving | Check that `travel_db` database exists with the tables |
| Live Server not working | Install "Live Server" extension in VS Code |

---

## API Endpoints Reference

| Method | Endpoint | What it does |
|--------|----------|-------------|
| POST | /api/auth/register | Create new user account |
| POST | /api/auth/login | Login user |
| GET | /api/destinations | Get all destinations |
| POST | /api/booking | Create a booking |
| POST | /api/admin/login | Admin login |
| GET | /api/admin/bookings | Get all bookings (admin) |
| GET | /api/admin/users | Get all users (admin) |
